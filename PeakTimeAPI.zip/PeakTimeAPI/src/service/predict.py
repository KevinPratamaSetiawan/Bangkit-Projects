# script.py
import sys
import json
import numpy as np
import ydf

def main():
    # Read the JSON string from the command-line arguments
    json_str = sys.argv[1]

    # Parse the JSON string into a Python list
    data = json.loads(json_str)
    data = np.array(data)
    
    model_path = '../chronotype_model_savedmodel'
    model_from_tfdf = ydf.from_tensorflow_decision_forests(model_path)

    features = {
        'Age': data[0],
        'Task': data[1],
        'average_rest': data[2],
        'mood_before_work': data[3],
        'deadline': data[4],
        'importance': data[5],
        'sleep_average': data[6],
        'urgency': data[7],
        'total_gangguan': data[8],
        'average_work_hour': data[9],
        'work_days': data[10]
    }

    print(model_from_tfdf.predict(features))

if __name__ == "__main__":
    main()